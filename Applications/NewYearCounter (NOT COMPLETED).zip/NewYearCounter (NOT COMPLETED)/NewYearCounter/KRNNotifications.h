//
//  KRNNotifications.h
//  UpToNewYear
//
//  Created by Drapaylo Yulian on 25.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import <Foundation/Foundation.h>
@import UIKit;


@interface KRNNotifications : NSObject

+(void) addNotifications; // добавить в приложение уведомления
+(void) removeNotifications; // удалить уведомления

@end
