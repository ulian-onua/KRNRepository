//
//  KRNOptionsTableVCTableViewController.m
//  UpToNewYear
//
//  Created by Drapaylo Yulian on 25.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "KRNOptionsTableVC.h"

@interface KRNOptionsTableVC ()

@end

@implementation KRNOptionsTableVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    // инициализация переключателей с NSDefaults
    NSNumber *tempNum = [[NSUserDefaults standardUserDefaults] objectForKey:KRNNotificationsOn];
    
    
    _notificationSwitch.on = [tempNum boolValue];
    
    tempNum = [[NSUserDefaults standardUserDefaults] objectForKey:KRNRemindersOn];
    
    _remindersSwitch.on = [tempNum boolValue];
    
    
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)backButtonAction:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (IBAction)notificationsSwitchAction:(id)sender
{
    
    UISwitch *tempSwitch = (UISwitch *) sender;
    
    if ([tempSwitch isOn]) // если свитч был включен
        [KRNNotifications addNotifications]; // добавим нотификации
    else
        [KRNNotifications removeNotifications]; // удалить нотификации
    
    // сохраняем User Defaults, используя отдельный поток
    dispatch_queue_t tempQueue = dispatch_queue_create("com.DrapayloYulian.tempQueue", DISPATCH_QUEUE_CONCURRENT);
    
    dispatch_async(tempQueue, ^{
        [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:tempSwitch.isOn] forKey:KRNNotificationsOn];
    });
    
    
    
}




- (IBAction)remindersSwitchAction:(id)sender
{
    UISwitch *tempSwitch = (UISwitch*) sender;
    
    if ([tempSwitch isOn])
        [KRNReminders addReminders];
    else
        [KRNReminders removeReminders];
    
      // сохраняем User Defaults, используя отдельный поток
    
    dispatch_queue_t tempQueue = dispatch_queue_create("com.DrapayloYulian.tempQueue", DISPATCH_QUEUE_CONCURRENT);
    
    dispatch_async(tempQueue, ^{
        [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithBool:tempSwitch.isOn] forKey:KRNRemindersOn];
    });

}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1)
        if (indexPath.row == 3)
        {
            [KRNShareEmail sendEmailTo:@"" withSubject:@"Up to New Year" withBody:@"UP TO NEW YEAR"];
        }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}



@end
