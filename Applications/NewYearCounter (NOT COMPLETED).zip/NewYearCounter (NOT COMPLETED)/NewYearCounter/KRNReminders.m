//
//  KRNReminders.m
//  UpToNewYear
//
//  Created by Drapaylo Yulian on 11.01.16.
//  Copyright © 2016 Drapaylo Yulian. All rights reserved.
//


#import "KRNReminders.h"

NSString* reminderIdentifier = nil;

NSString* const KRNRemindersSavedNotification = @"KRNRemindersSavedNotification";


@implementation KRNReminders

+(void) addReminders
{
    EKEventStore *evStore = [[EKEventStore alloc] init];
    [evStore requestAccessToEntityType:EKEntityTypeReminder completion:^(BOOL granted, NSError * _Nullable error) {
            // добавить вывод UIAlertController'а о невозможности добавления
    }];
    
    
    EKReminder* timeToNewYearReminder = [EKReminder reminderWithEventStore:evStore];
    timeToNewYearReminder.calendar = [evStore defaultCalendarForNewReminders]; // получаем дефолтный календарь
    timeToNewYearReminder.title = @"Check time up to New Year!!";
    timeToNewYearReminder.notes = @"Check time up to New Year by launching UpToNewYear app";
    
    timeToNewYearReminder.completionDate = [NSDate dateWithTimeIntervalSinceNow:30];
    timeToNewYearReminder.completed = NO;
    timeToNewYearReminder.priority = 1;
    
    
    // создаем и добавляем alarm
    EKAlarm* alarm = [EKAlarm alarmWithRelativeOffset:10];
    
    [timeToNewYearReminder addAlarm:alarm];
    
    
    
    
    unsigned unitFlags= NSCalendarUnitYear|NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour |NSCalendarUnitMinute|NSCalendarUnitSecond|NSCalendarUnitTimeZone;
    
    NSDateComponents *dailyComponents=[[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian] components:unitFlags fromDate:[NSDate dateWithTimeIntervalSinceNow:10]];
    
    [timeToNewYearReminder setDueDateComponents:dailyComponents];
    
    
    // создаем и добавляем правило повторения
    
    EKRecurrenceRule *recRule = [[EKRecurrenceRule alloc]initRecurrenceWithFrequency:EKRecurrenceFrequencyDaily interval:1 end:nil];
    
    [timeToNewYearReminder addRecurrenceRule:recRule];
    
    //добавляем напоминание в Event Store
    
    NSError* error;
    
    [evStore saveReminder:timeToNewYearReminder commit:YES error:&error];
    if (error)
    {
        NSLog(@"Error adding reminder: %@", error.localizedDescription);
        
    }
    
    reminderIdentifier = [NSString stringWithString:timeToNewYearReminder.calendarItemIdentifier];
    
    [[NSUserDefaults standardUserDefaults] setObject:reminderIdentifier forKey:KRNRemindersSavedNotification];
    
    
}

+(void) removeReminders
{
   
    reminderIdentifier =
    [[NSUserDefaults standardUserDefaults] objectForKey:KRNRemindersSavedNotification ];
 
    if (reminderIdentifier != nil)
    {
    
    EKEventStore *evStore = [[EKEventStore alloc] init];
    [evStore requestAccessToEntityType:EKEntityTypeReminder completion:^(BOOL granted, NSError * _Nullable error) {
        // добавить вывод UIAlertController'а о невозможности добавления
    }];
    
    EKReminder *removedReminder = (EKReminder*) [evStore calendarItemWithIdentifier:reminderIdentifier];
    
    NSError* error;
    [evStore removeReminder:removedReminder commit:YES error:&error];
    if (error)
    {
        NSLog(@"Error removing reminder: %@", error.localizedDescription);
        return;
    }
        reminderIdentifier = nil;
    }
    
}

@end
