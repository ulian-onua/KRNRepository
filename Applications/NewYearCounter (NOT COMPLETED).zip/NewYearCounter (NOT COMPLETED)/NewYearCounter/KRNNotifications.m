//
//  KRNNotifications.m
//  UpToNewYear
//
//  Created by Drapaylo Yulian on 25.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "KRNNotifications.h"

@implementation KRNNotifications

+(void) addNotifications
{
    if ([UIApplication sharedApplication].scheduledLocalNotifications.count !=0)
        return; // на всякий случай, проверим не установлены ли уже нотификации. Если да, то выйдем из функции.
    
    // устанавливаем настройки
    UIUserNotificationType types =  UIUserNotificationTypeAlert | UIUserNotificationTypeSound;
    
    UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:(types) categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    
    
    // добавляем нотификацию
    
    UILocalNotification *localNotif = [[UILocalNotification alloc] init];
    
    localNotif.fireDate = [NSDate dateWithTimeInterval:120 sinceDate:[NSDate date]]; // через две минуты после текущей даты
    localNotif.timeZone = [NSTimeZone defaultTimeZone];
    
    localNotif.applicationIconBadgeNumber = 1;
    localNotif.soundName = UILocalNotificationDefaultSoundName;
    
    
    localNotif.alertTitle = @"TimeToNewYear";
    localNotif.alertBody = @"Check time up to New Year!!";


    
    localNotif.repeatInterval = kCFCalendarUnitDay;
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotif];

}

+(void) removeNotifications // удалить уведомления
{
    [[UIApplication sharedApplication] cancelAllLocalNotifications];

}

@end
