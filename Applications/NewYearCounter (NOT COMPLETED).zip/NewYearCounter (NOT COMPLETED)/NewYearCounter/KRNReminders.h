//
//  KRNReminders.h
//  UpToNewYear
//
//  Created by Drapaylo Yulian on 11.01.16.
//  Copyright © 2016 Drapaylo Yulian. All rights reserved.
//

#import <Foundation/Foundation.h>
@import EventKit;

@interface KRNReminders : NSObject

+(void) addReminders;
+(void) removeReminders;

@end
