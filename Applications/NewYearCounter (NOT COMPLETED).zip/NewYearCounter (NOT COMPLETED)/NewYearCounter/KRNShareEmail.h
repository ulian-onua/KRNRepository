//
//  KRNShareEmail.h
//  UpToNewYear
//
//  Created by Drapaylo Yulian on 11.01.16.
//  Copyright © 2016 Drapaylo Yulian. All rights reserved.
//


@import Foundation;
@import UIKit;

#import "KRNTimeToNewYear.h"

@interface KRNShareEmail : NSObject

+(void) sendEmailTo:(NSString *)to withSubject:(NSString *)subject withBody:(NSString *)body;

@end
