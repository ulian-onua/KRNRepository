//
//  KRNPeripheralCell.h
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 28.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KRNPeripheralCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *peripheralDeviceName;
@property (weak, nonatomic) IBOutlet UILabel *peripheralDeviceID;
@property (weak, nonatomic) IBOutlet UILabel *peripheralDeviceRSSI;
@property (weak, nonatomic) IBOutlet UILabel *timeOfDiscover;


- (void) addNeededName:(NSString*)name ID:(NSString*) identifier RSSI: (NSString*) rssi andDate:(NSDate*) date; // добавить необходимые данные, а функция их отформатирует

@end
