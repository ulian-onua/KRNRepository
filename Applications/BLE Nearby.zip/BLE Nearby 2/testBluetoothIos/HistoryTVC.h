//
//  HistoryTVC.h
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 10.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "KRNCoreData.h"
#import "KRNPeripheralCDController.h"

#import "KRNHistoryCell.h"

#import "KRNExtendedTVC.h"

@interface HistoryTVC : UITableViewController
- (IBAction)deleteAllOutlet:(id)sender;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *deleteAllButton;

@end
