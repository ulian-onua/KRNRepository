//
//  PeripheralDevice.h
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 10.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AdvertisementData.h"

@class AdvertisementData;

NS_ASSUME_NONNULL_BEGIN

@interface PeripheralDevice : NSManagedObject



@end

NS_ASSUME_NONNULL_END

#import "PeripheralDevice+CoreDataProperties.h"
