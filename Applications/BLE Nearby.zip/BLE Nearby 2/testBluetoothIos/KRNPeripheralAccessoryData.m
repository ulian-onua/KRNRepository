//
//  KRNPeripheralAccessoryData.m
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 29.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "KRNPeripheralAccessoryData.h"

@implementation KRNPeripheralAccessoryData

-(id) initWithAssociatedRSSI:(NSNumber *) RSSI andAdvertisemendData: (NSDictionary<NSString *, id> *) data
{
    self = [super init];
    
    if (self)
    {
        _associatedRSSI = RSSI;
        _associatedDate = [NSDate date];
        _advertisementData = [NSDictionary dictionaryWithDictionary:data];
        
        
    }
    
    return self;
    
    
}
+ (id) peripheralAccessoryDataWithAssociatedRSSI:(NSNumber *) RSSI andAdvertisemendData: (NSDictionary<NSString *, id> *) data
{
    KRNPeripheralAccessoryData *temp = [[KRNPeripheralAccessoryData alloc] initWithAssociatedRSSI:RSSI andAdvertisemendData:data];
    
    return temp;
}




@end
