//
//  KRNPeripheralAccessoryData.h
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 29.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KRNPeripheralAccessoryData : NSObject

@property NSNumber* associatedRSSI; // RSSI, которые соответствуют им
@property NSDate* associatedDate; // связанная дата с найденным CBPeripheral
@property NSDictionary<NSString *, id> *advertisementData; // данные с оповещением


-(id) initWithAssociatedRSSI:(NSNumber *) RSSI andAdvertisemendData: (NSDictionary<NSString *, id> *) data;
+ (id) peripheralAccessoryDataWithAssociatedRSSI:(NSNumber *) RSSI andAdvertisemendData: (NSDictionary<NSString *, id> *) data;


@end
