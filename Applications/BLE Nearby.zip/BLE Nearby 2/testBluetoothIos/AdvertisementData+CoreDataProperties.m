//
//  AdvertisementData+CoreDataProperties.m
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 10.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AdvertisementData+CoreDataProperties.h"

@implementation AdvertisementData (CoreDataProperties)

@dynamic data;
@dynamic peripheral;

@end
