//
//  KRNExtendedTVC.m
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 29.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "KRNExtendedTVC.h"

@interface KRNExtendedTVC ()
@property NSArray* allObjects;
@property NSArray<NSString*> *allKeys;

@end

@interface NSArray (NSStringArraySortUsingTemplate)

- (NSArray*) sortArrayUsingTemplate:(NSArray*)templateArray; // функция сортирует массив в соответствии с порядком, указанном в переданном массиве ключей



@end


@implementation NSArray (NSStringArraySortUsingTemplate)

- (NSArray<NSString*> *) sortArrayUsingTemplate:(NSArray<NSString*>*)templateArray
{
    NSArray <NSString*> *returnedArray = nil;
    
    NSMutableArray <NSString*> *tempArray = [NSMutableArray new];
    
    for (int i = 0; i < templateArray.count; i++)
    {
        for (int i2 = 0; i2 < self.count ; i2++) {
            
            if ([self[i2] isEqualToString:templateArray[i]])
            {
                [tempArray addObject:self[i2]];
                break;
            }
            
        }
    }
    
    returnedArray = [NSArray arrayWithArray:tempArray];
    
    
    return returnedArray;
}

@end

@implementation KRNExtendedTVC





- (void)viewDidLoad {
    [super viewDidLoad];
    //NSLog(@"Advertising data: %@", _concretePeripheral.advertisementData);
    
//    KRNPeripheralWithAttr* peripheral = [[KRNPeripheralWithAttr alloc] init];
//    peripheral.advertisementData = @{CBAdvertisementDataLocalNameKey : @"", CBAdvertisementDataManufacturerDataKey : @"", CBAdvertisementDataServiceDataKey : @"",CBAdvertisementDataIsConnectable : @""};
//    
//    _concretePeripheral = peripheral;
    
    
    
    _allKeys = [_concretePeripheral.advertisementData allKeys];
    
   _allKeys = [_allKeys sortArrayUsingTemplate:@[CBAdvertisementDataLocalNameKey, CBAdvertisementDataManufacturerDataKey, CBAdvertisementDataServiceDataKey, CBAdvertisementDataServiceUUIDsKey, CBAdvertisementDataOverflowServiceUUIDsKey, CBAdvertisementDataTxPowerLevelKey, CBAdvertisementDataIsConnectable, CBAdvertisementDataSolicitedServiceUUIDsKey]];
                         

    
    //NSLog(@"All keys = %@", _allKeys);
    //NSLog(@"All objects = %@", _allObjects);
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return [_concretePeripheral.advertisementData count]; // возвращаем в соответствии с количеством значений в словаре
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self numbersOfRowForStringConstant:_allKeys[section]]; // возвращаем данные для ключа в зависимости от секции
    
}

- (NSInteger) numbersOfRowForStringConstant:(NSString*)constant // функция для расчета количество строк в зависимости от константы словаря
{
    if ([constant isEqualToString:CBAdvertisementDataLocalNameKey] || [constant isEqualToString:CBAdvertisementDataManufacturerDataKey] || [constant isEqualToString:CBAdvertisementDataIsConnectable] || [constant isEqualToString:CBAdvertisementDataTxPowerLevelKey]  )
    {
        id tempObj = [_concretePeripheral.advertisementData objectForKey:constant];
        
        if (tempObj)
            return 1;
        else
            return 0;

    }
    else if ([constant isEqualToString:CBAdvertisementDataServiceDataKey])
    {
        NSDictionary* tempDict = [_concretePeripheral.advertisementData objectForKey:constant];
        
        if (tempDict)
            return [tempDict count];
        else
            return 0;
    }
    else if ([constant isEqualToString:CBAdvertisementDataServiceUUIDsKey] || [constant isEqualToString:CBAdvertisementDataOverflowServiceUUIDsKey] || [constant isEqualToString:CBAdvertisementDataSolicitedServiceUUIDsKey])
    {
        NSArray *tempArray = [_concretePeripheral.advertisementData objectForKey:constant];
        if (tempArray)
            return [tempArray count];
        else
            return 0;
    }
   
    
    
    return 0;
    
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
       return [self titleForHeaderForStringConstant:_allKeys[section]]; // возвращаем данные для ключа в зависимости от секции
}

-(NSString*) titleForHeaderForStringConstant:(NSString*)constant // функция определения титула для заголовка секции
{
    if ([constant isEqualToString:CBAdvertisementDataLocalNameKey])
        return @"Device Local Name";
    else
        if ([constant isEqualToString:CBAdvertisementDataIsConnectable])
            return @"Is connectable";
    else
        if ([constant isEqualToString:CBAdvertisementDataServiceDataKey])
            return @"Service Data";
    else
        if ([constant isEqualToString:CBAdvertisementDataManufacturerDataKey])
            return @"Manufacturer Data Key";
    else
        if ([constant isEqualToString:CBAdvertisementDataServiceUUIDsKey])
            return @"Service UUIDs";
    else
        if ([constant isEqualToString:CBAdvertisementDataTxPowerLevelKey])
            return @"Transmit Power";
    else
        if ([constant isEqualToString:CBAdvertisementDataOverflowServiceUUIDsKey])
            return @"Overflow service UUIDs";
    else
        if ([constant isEqualToString:CBAdvertisementDataSolicitedServiceUUIDsKey])
            return @"Solicited service UUIDs";
    
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //KRNPeripheralCell *cell = [[KRNPeripheralCell alloc] init];
    
    return [self tableViewCell:tableView withIndexPath:indexPath ForStringConstant:_allKeys[indexPath.section]];


}

-(id) tableViewCell: (UITableView*) tableView withIndexPath: (NSIndexPath*) indexPath ForStringConstant:(NSString*)constant
{
    if ([constant isEqualToString:CBAdvertisementDataLocalNameKey])
    {
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"CellConnectivity"];
        cell.textLabel.text = [_concretePeripheral.advertisementData objectForKey:constant];
       // cell.textLabel.text = @"MI1A";
        return cell;
    }
    else if ([constant isEqualToString:CBAdvertisementDataIsConnectable]) // если нужно вернуть ячейку: "подключаем ли девайс"
    {
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"CellConnectivity"];
        NSNumber* tempNum = [_concretePeripheral.advertisementData objectForKey:constant];
        
        cell.textLabel.text = [tempNum isEqualToNumber:@1] ?     @"Device is connectable" : @"Device is not connectable";
        
         //cell.textLabel.text = @"Device is connectable";
         return cell;
        
    }
    else if ([constant isEqualToString:CBAdvertisementDataServiceDataKey])
    {
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"CellConnectivity"];
        NSDictionary* tempDict = [_concretePeripheral.advertisementData objectForKey:constant];
        
        NSArray <CBUUID*> *allTempKeys = [tempDict allKeys];
        NSArray <NSData*> *allTempObjects = [tempDict allValues];
        
   
        cell.textLabel.text = [NSString stringWithFormat:@"0x%@ = 0x%@", allTempKeys[indexPath.row].UUIDString, allTempObjects[indexPath.row].hexadecimalString];
        
       // cell.textLabel.text = [NSString stringWithFormat:@"0x%@ = 0x%@", @"FEE0", @"20000000"];
        
         return cell;
    }
    else if ([constant isEqualToString:CBAdvertisementDataServiceUUIDsKey] || [constant isEqualToString:CBAdvertisementDataOverflowServiceUUIDsKey] || [constant isEqualToString:CBAdvertisementDataSolicitedServiceUUIDsKey])
    {
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"CellConnectivity"];
            
        NSArray <CBUUID*> *tempArr = [_concretePeripheral.advertisementData objectForKey:constant];
     
        cell.textLabel.text = [NSString stringWithFormat:@"0x%@", tempArr[indexPath.row].UUIDString];
        cell.textLabel.numberOfLines = 0;
        cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
        CGSize maximumLabelSize = CGSizeMake(cell.textLabel.frame.size.width, CGFLOAT_MAX);
        CGSize expectSize = [cell.textLabel sizeThatFits:maximumLabelSize];
        cell.textLabel.frame = CGRectMake(cell.textLabel.frame.origin.x, cell.textLabel.frame.origin.y, expectSize.width, expectSize.height);
        return cell;
            
    }
    else if ([constant isEqualToString:CBAdvertisementDataManufacturerDataKey])
    {
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"CellConnectivity"];
        
        NSData* dataKey = [_concretePeripheral.advertisementData objectForKey:constant];
        
        cell.textLabel.text = [NSString stringWithFormat:@"0x%@", [dataKey hexadecimalString]];
        //cell.textLabel.text = [NSString stringWithFormat:@"0x%@", @"570100b367d459ca9d92351405c12132693b6501880f10e0cd35"];
        
        cell.textLabel.numberOfLines = 0;
        cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
        CGSize maximumLabelSize = CGSizeMake(cell.textLabel.frame.size.width, CGFLOAT_MAX);
        CGSize expectSize = [cell.textLabel sizeThatFits:maximumLabelSize];
        cell.textLabel.frame = CGRectMake(cell.textLabel.frame.origin.x, cell.textLabel.frame.origin.y, expectSize.width, expectSize.height);
        
        return cell;
    }
    else if ([constant isEqualToString:CBAdvertisementDataTxPowerLevelKey])
    {
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"CellConnectivity"];
        
        NSNumber* txPower = [_concretePeripheral.advertisementData objectForKey:constant];
        cell.textLabel.text = [txPower stringValue];
        return cell;
    }
    
//        An array of service UUIDs.

    else return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1 || indexPath.section == 2 || indexPath.section == 3)
        if (indexPath.row == 0)
            return 50;
  
    
    return 50;
}





- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if ([self tableView: tableView numberOfRowsInSection: section] == 0) {
        return 0.01f;;
    }
    
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if ([self tableView: tableView numberOfRowsInSection: section] == 0) {
        return 0.01f;;
    }
    
    return UITableViewAutomaticDimension;
}

@end


@implementation NSData (NSData_Conversion)

#pragma mark - String Conversion
- (NSString *)hexadecimalString {
    /* Returns hexadecimal string of NSData. Empty string if data is empty.   */
    
    const unsigned char *dataBuffer = (const unsigned char *)[self bytes];
    
    if (!dataBuffer)
        return [NSString string];
    
    NSUInteger          dataLength  = [self length];
    NSMutableString     *hexString  = [NSMutableString stringWithCapacity:(dataLength * 2)];
    
    for (int i = 0; i < dataLength; ++i)
        [hexString appendString:[NSString stringWithFormat:@"%02lx", (unsigned long)dataBuffer[i]]];
    
    return [NSString stringWithString:hexString];
}

@end

