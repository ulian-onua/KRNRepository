//
//  KRNCoreData.m
//  TableInTable
//
//  Created by Drapaylo Yulian on 01.11.15.
//  Copyright © 2015 Administrator. All rights reserved.
//

#import "KRNCoreData.h"


static KRNCoreData* coreData = nil; //


@interface KRNCoreData()


@end

@implementation KRNCoreData

+ (KRNCoreData *)defaultCoreData
{
    if (coreData == nil)
        coreData = [[super allocWithZone:NULL] init];
    
    return coreData;
    
    
}

+(id) allocWithZone:(struct _NSZone *)zone
{
    return [self defaultCoreData];
}

-(id) copy
{
    return self;
}


//-(void)saveContext; // сохранить контекст


- (NSManagedObjectModel *) managedObjectModel
{
    if (_managedObjectModel) // если модель уже создана
        return _managedObjectModel;
    
    
    // если нет, то получаем ее с директории
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"PeripheralModel" withExtension:@"momd"];
    
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    
    
    return _managedObjectModel;
    
    
    
}


- (NSPersistentStoreCoordinator*)persistentStoreCoordinator
{
    if (_persistentStoreCoordinator)
        return _persistentStoreCoordinator;
    
    
    // если _persistentStoreCoodinator не создан, то нужно определить его тип и создать
    
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:self.managedObjectModel];
    
    
    NSURL* storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"peripheralmodel.sql"]; // определяем место хранения
    
    NSError *error;
    
    if (! [_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error])
    {
        //NSLog (@"Error when trying to initialize persistent store coordinator: %@", error);
        abort();
    }
    
    return _persistentStoreCoordinator;
    
    
}

- (NSManagedObjectContext*)managedObjectContext
{
    if (_managedObjectContext)
        return _managedObjectContext;
    
    _managedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType: NSMainQueueConcurrencyType];
    [_managedObjectContext setPersistentStoreCoordinator:self.persistentStoreCoordinator];
    
    return _managedObjectContext;
}


- (void)saveContext // сохранить контекст
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    if(managedObjectContext != nil) {
        if([managedObjectContext hasChanges] && ![managedObjectContext save:&error]){
            //NSLog(@"Unresolved error while saving context %@, %@", error, [error userInfo]);
            abort();
        }
    }
}



- (NSURL *)applicationDocumentsDirectory  // определяем директорию, в которой будет храниться база данных
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}




@end
