//
//  TableViewController.h
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 28.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import <UIKit/UIKit.h>
@import CoreBluetooth;


#import "KRNPeripheralCell.h"
#import "KRNPeripheralAccessoryData.h"
#import "KRNExtendedTVC.h"

#import "KRNPeripheralWithAttr.h"

#import "KRNPeripheralCDController.h"
#import "KRNCoreData.h"

@interface TableViewController : UITableViewController

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *scanActivityIndicator;
@property (weak, nonatomic) IBOutlet UIButton *scanButton;

- (IBAction)scanButtonAction:(id)sender;


@property KRNCoreData *coreData;
@property KRNPeripheralCDController *coreDataController;





@end
