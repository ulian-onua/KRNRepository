//
//  KRNPeripheralWithAttr.h
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 02.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import <CoreBluetooth/CoreBluetooth.h>



@protocol KRNExtendedTVCProtocol <NSObject>

-(NSDictionary<NSString *, id> *)advertisementData;


@end


@interface KRNPeripheralWithAttr : NSObject <KRNExtendedTVCProtocol>

@property CBPeripheral* peripheral;

@property NSNumber* associatedRSSI; // RSSI, который соответствует периферийному устройства
@property NSDate* associatedDate; // связанная дата с найденным CBPeripheral
@property NSDictionary<NSString *, id> *advertisementData; // данные с оповещением



-(void) addAssociatedRSSI:(NSNumber *) RSSI andAdvertisemendData: (NSDictionary<NSString *, id> *) data;



@end
