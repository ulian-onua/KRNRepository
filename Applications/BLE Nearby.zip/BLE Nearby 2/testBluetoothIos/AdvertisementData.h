//
//  AdvertisementData.h
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 10.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class PeripheralDevice;

NS_ASSUME_NONNULL_BEGIN

@interface AdvertisementData : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "AdvertisementData+CoreDataProperties.h"
