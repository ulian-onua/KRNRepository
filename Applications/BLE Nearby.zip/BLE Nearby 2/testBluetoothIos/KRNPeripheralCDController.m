//
//  KRNPeripheralCDController.m
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 10.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "KRNPeripheralCDController.h"




@interface KRNPeripheralCDController ()

@property NSManagedObjectContext* context;

@end

@implementation KRNPeripheralCDController

-(id) initWithCDContext:(NSManagedObjectContext*) context AndDelegate:(id<KRNPeripheralCDControllerProtocol>) delegate
{
    self = [super init];
    if (self)
    {
        _context = context;
        _delegate = delegate;
    }
    return self;
}

-(BOOL) addKRNPeripheral:(KRNPeripheralWithAttr*)peripheral
{
    PeripheralDevice *device = [NSEntityDescription insertNewObjectForEntityForName:@"PeripheralDevice" inManagedObjectContext:_context];
    device.peripheralID = peripheral.peripheral.identifier.UUIDString;
    device.peripheralName = peripheral.peripheral.name;
    device.peripheralRSSI = peripheral.associatedRSSI;
    device.storedDate = peripheral.associatedDate;
    
    device.advertisementData = [NSEntityDescription insertNewObjectForEntityForName: @"AdvertisementData" inManagedObjectContext:_context];
    
    device.advertisementData.data = [NSKeyedArchiver archivedDataWithRootObject:peripheral.advertisementData];
    
    NSError* error;
    
    [_context save:&error];
    
    if (error)
    {
        //NSLog(@"Error saving context.Error = %@", error.localizedDescription);
        return false;
    }
    
    
    return true;
}


-(NSArray<PeripheralDevice*> *) fetchAllPeripheralDevicesFromCD
{
    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"PeripheralDevice"];
    
    NSError* error;
    
    _fetchedPeripherals = (NSMutableArray*) [_context executeFetchRequest:fetchRequest error:&error];
    if (error)
    {
        //NSLog(@"Error fetching request for KRNPeripherals.Error = %@", error.localizedDescription);
        _fetchedPeripherals = nil;
    }
    
    else
    {
        if (_fetchedPeripherals.count > 0)
            [_delegate peripheralsinCDFound:self]; // сообщение делегату, что один или более периферийных устройств найены в Core Data
        else
            [_delegate findedNoPeripheralsinCD:self]; // сообщение делегату, что периферийные устройства не найдены в Core Data

    }
    
    

    return _fetchedPeripherals;
}

-(BOOL)deleteAllKRNPeripheralsFromCD
{
    for (PeripheralDevice* krnPeripheral in _fetchedPeripherals)
        [_context deleteObject:krnPeripheral];
    
    
    NSError* error;
    [_context save:&error];
    
    if (error)
    {
        //NSLog(@"Error deleting all objects in context.Error = %@", error.localizedDescription);
        return false;
    }
    
  
    
    return true;
}

-(BOOL) deleteKRNPeripheralAtRow:(NSUInteger)tableViewRow
{
    [_context deleteObject: _fetchedPeripherals[tableViewRow]];
    
    
     NSError* error;
    [_context save:&error];
    
    if (error)
    {
        //NSLog(@"Error delete object.Error = %@", error.localizedDescription);
        return false;
    }
    
    
    return true;
}



@end


@implementation CBUUID (NSCoding)

- (instancetype)initWithCoder:(NSCoder *)decoder
{
    self = [CBUUID UUIDWithString:[decoder decodeObjectForKey:@"CBUUIDString"]];
    
    
    return self;
}
- (void)encodeWithCoder:(NSCoder *)encoder
{
    [encoder encodeObject:[self UUIDString] forKey:@"CBUUIDString"];
}



@end
