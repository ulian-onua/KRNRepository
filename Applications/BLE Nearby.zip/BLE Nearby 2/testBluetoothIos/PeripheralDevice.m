//
//  PeripheralDevice.m
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 10.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "PeripheralDevice.h"
#import "AdvertisementData.h"

@implementation PeripheralDevice


// NSDictionary* tempDict = [;

@end
