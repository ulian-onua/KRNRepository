//
//  HistoryTVC.m
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 10.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "HistoryTVC.h"

@interface HistoryTVC ()<KRNPeripheralCDControllerProtocol>
{
    NSInteger selectedRow; // последняя выделенная строка в таблице
    
}

@property KRNPeripheralWithAttr* tempAttr;

@property KRNPeripheralCDController* coreDataController;



@end

@implementation HistoryTVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _coreDataController = [[KRNPeripheralCDController alloc] initWithCDContext:[[KRNCoreData defaultCoreData] managedObjectContext] AndDelegate:self];
    
    
    [_coreDataController fetchAllPeripheralDevicesFromCD];
    
  //  [_deleteAllButton setEnabled:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [_coreDataController fetchedPeripherals].count;
   // return 10;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    KRNHistoryCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HistoryCell" forIndexPath:indexPath];
    
   [cell addDeviceName:_coreDataController.fetchedPeripherals[indexPath.row].peripheralName AndDate:_coreDataController.fetchedPeripherals[indexPath.row].storedDate];
    
    
//    switch (indexPath.row) {
//        case 9:
//            [cell addDeviceName:@"MI" AndDate:[NSDate dateWithTimeInterval:-86400 sinceDate:[NSDate date]]];
//            break;
//        case 8:
//            [cell addDeviceName:@"Mac Mini - Drapaylo" AndDate:[NSDate dateWithTimeInterval:-53400 sinceDate:[NSDate date]]];
//             
//            break;
//        case 7:
//            [cell addDeviceName:@"DLM" AndDate:[NSDate dateWithTimeInterval:-41234 sinceDate:[NSDate date]]];
//
//            break;
//        case 6:
//            [cell addDeviceName:@"BLE112" AndDate:[NSDate dateWithTimeInterval:-30234 sinceDate:[NSDate date]]];
//            break;
//        case 5:
//            [cell addDeviceName:@"MI" AndDate:[NSDate dateWithTimeInterval:-25234 sinceDate:[NSDate date]]];
//            break;
//        case 4:
//            [cell addDeviceName:@"iPhone 5s - Max" AndDate:[NSDate dateWithTimeInterval:-25000 sinceDate:[NSDate date]]];
//            break;
//        case 3:
//            [cell addDeviceName:@"iPhone 6s - Helen" AndDate:[NSDate date]];
//            break;
//        case 2:
//            [cell addDeviceName:@"Mac Mini - Drapaylo" AndDate:[NSDate date]];
//            break;
//        case 1:
//            [cell addDeviceName:@"MI" AndDate:[NSDate date]];
//            break;
//        case 0:
//            [cell addDeviceName:@"MI" AndDate:[NSDate date]];
//            break;
//            
//            
//        default:
//            break;
//    }
//    
    
    
  //  NSDictionary* tempDict = [NSKeyedUnarchiver unarchiveObjectWithData:_coreDataController.fetchedPeripherals[indexPath.row].advertisementData.data];
    
    //NSLog(@"%@", tempDict);
    
    
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    selectedRow = indexPath.row;
    [self performSegueWithIdentifier:@"toExtendedTVC2" sender:self];
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [_coreDataController deleteKRNPeripheralAtRow:indexPath.row];
         [_coreDataController fetchAllPeripheralDevicesFromCD];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
       
    }
    
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"toExtendedTVC2"])
    {
        KRNExtendedTVC *destinationTVC = segue.destinationViewController;
        
        
        _tempAttr = [[KRNPeripheralWithAttr alloc] init];
        
        _tempAttr.advertisementData = [NSKeyedUnarchiver unarchiveObjectWithData:_coreDataController.fetchedPeripherals[selectedRow].advertisementData.data];
        
        // передаем необходимые данные
        destinationTVC.concretePeripheral = _tempAttr;

    }
    
}

- (IBAction)deleteAllOutlet:(id)sender
{
    [_coreDataController deleteAllKRNPeripheralsFromCD];
    [_coreDataController fetchAllPeripheralDevicesFromCD];
    [self.tableView reloadData];
}

#pragma mark - delegate methods

-(void) findedNoPeripheralsinCD:(KRNPeripheralCDController*) controller // ни одного периферийного устройства не найдено
{
    [_deleteAllButton setEnabled:NO];
}

-(void) peripheralsinCDFound:(KRNPeripheralCDController*) controller
{
    [_deleteAllButton setEnabled:YES];
}// найден один или более периферийных устройств в CD
@end
