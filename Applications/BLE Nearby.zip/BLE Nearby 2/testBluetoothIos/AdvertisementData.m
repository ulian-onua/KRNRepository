//
//  AdvertisementData.m
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 10.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "AdvertisementData.h"
#import "PeripheralDevice.h"

@implementation AdvertisementData

// Insert code here to add functionality to your managed object subclass

@end
