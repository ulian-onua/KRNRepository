//
//  TableViewController.m
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 28.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "TableViewController.h"

static BOOL currentScanButtonState = NO; // сканирование не запущено

@interface TableViewController () <CBCentralManagerDelegate>

{
    NSInteger selectedRow; // последняя выделенная строка в таблице
}


@property NSMutableArray<KRNPeripheralWithAttr*> *findedPeripherals; // найденные периферийные устройства

//
//@property NSMutableArray <KRNPeripheralAccessoryData *> *accessoryDataArray; // массив с классами дополнительных данных


@property (strong) CBCentralManager *bluetoothManager; // bluetoothManager

@property (retain) dispatch_queue_t bluetoothManagerQueue; // поток для bluetooth Manager




@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
    _coreData = [KRNCoreData defaultCoreData];
    _coreDataController = [[KRNPeripheralCDController alloc] initWithCDContext:_coreData.managedObjectContext AndDelegate:nil];
    
    
    _bluetoothManagerQueue = dispatch_queue_create("com.testBluetooth.myQueue", NULL);
    
    
    _bluetoothManager = [[CBCentralManager alloc] initWithDelegate:self queue:_bluetoothManagerQueue options:@{CBCentralManagerOptionShowPowerAlertKey : @YES}]; // в случае, если Bluetooth не включен, то будет появляться соответствующее сообщение
    

    
    _findedPeripherals = [NSMutableArray new];

    
    _scanActivityIndicator.hidden = YES;
    
    
   //[self performSegueWithIdentifier:@"toExtendedTVC" sender:self];
    
 
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

   return _findedPeripherals.count; // количество найденных периферийных устройств
    //return 3;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    KRNPeripheralCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PeripheralCell" forIndexPath:indexPath];
    
    
    [cell addNeededName:_findedPeripherals[indexPath.row].peripheral.name ID:_findedPeripherals[indexPath.row].peripheral.identifier.UUIDString RSSI:[_findedPeripherals[indexPath.row].associatedRSSI stringValue] andDate:[_findedPeripherals[indexPath.row]associatedDate]]; // добавить данные в зависимости от индекса
     
    

    
//    if (indexPath.row == 0)
//    {
//        [cell addNeededName:@"MI" ID:@"D1EDBE49-4F93-B451-AE84-F675134B0EC4" RSSI:@"-92" andDate:[NSDate date]];
//        
//    }
//    
//    else if (indexPath.row == 1)
//        {
//            [cell addNeededName:@"Mac Mini - Drapaylo" ID:@"B28H1192-2B38-E573-688B-10A189560B93" RSSI:@"-59" andDate:[NSDate date]];
//            
//        }
//    else if (indexPath.row == 2)
//    {
//        [cell addNeededName:@"DBM" ID:@"27964A11-584A-49EB-A325-7DB426284631" RSSI:@"-64" andDate:[NSDate date]];
//        
//    }
    
    
    
    return cell;
}


- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    //NSLog(@"Accessory button tapped for row %ld", (long)indexPath.row);
    selectedRow = indexPath.row;
    [self performSegueWithIdentifier:@"toExtendedTVC" sender:self];

}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [_findedPeripherals removeObjectAtIndex:indexPath.row];
  
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
    
}



#pragma mark - Central Manager Delegate Methods

- (void)centralManagerDidUpdateState:(CBCentralManager *)central // обязательный метод делегата, который проверяет состояние устройства
{
    switch (central.state) {
        case CBCentralManagerStateUnknown:
        {
            //NSLog(@"CBCentralManagerState is unknown\n");
            break;
        }
        case CBCentralManagerStateResetting:
        {
            //NSLog(@"CBCentralManagerState is resetting\n");
            break;
        }
        case CBCentralManagerStateUnsupported:
        {
            //NSLog(@"CBCentralManagerState is unsupported\n");
            
            
            
            
            if ([UIAlertController class]) // если класс UIAlertController поддерживается
            {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                UIAlertController* myAlertController = [UIAlertController alertControllerWithTitle:@"State is unsupported!" message:@"You device doesn't support Bluetooth low energy 4. Scan cannot be performed." preferredStyle: UIAlertControllerStyleAlert];
                
                [myAlertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                    [myAlertController dismissViewControllerAnimated:YES completion:nil];
                }]];
                
                [self presentViewController:myAlertController animated:YES completion:nil];
                
            });
            }
            
            else // using UIAlertView
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:@"State is unsupported" message:@"You device doesn't support Bluetooth low energy 4. Scan cannot be performed." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                [alertView show];
                });
            }
           
            
            
            break;
        }
            
        case CBCentralManagerStateUnauthorized:
        {
            //NSLog(@"CBCentralManagerState is unathorized\n");
            break;
        }
        case CBCentralManagerStatePoweredOff:
        {
            //NSLog(@"CBCentralManagerState is Powered Off\n");
            
            if (currentScanButtonState == YES)
                dispatch_async(dispatch_get_main_queue(), ^{ // вызываем в главном потоке
                [_scanButton sendActionsForControlEvents:UIControlEventTouchUpInside];
              });

            break;
        }
            
        case CBCentralManagerStatePoweredOn:
        {
            //NSLog(@"CBCentralManagerState is Powered On\n");
          //  [_bluetoothManager scanForPeripheralsWithServices:nil options:nil];
           // [_bluetoothManager scanForPeripheralsWithServices:nil options:nil];
            break;
        }
            
            
        default:
            break;
    }
}

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *, id> *)advertisementData RSSI:(NSNumber *)RSSI
{
    NSUInteger idx; // индекс
    idx = [_findedPeripherals indexOfObjectPassingTest:^BOOL(KRNPeripheralWithAttr * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        if ([obj.peripheral.identifier.UUIDString isEqualToString:peripheral.identifier.UUIDString])
        {
            //NSLog(@"%@", obj.peripheral.identifier.UUIDString);
            //NSLog(@"%@", peripheral.identifier.UUIDString);
            *stop = YES;
            return YES;
        }
        
        return NO;
    }]; // осуществляем поиск такого же объекта в имеющемся массиве
    
    //NSLog(@"IDX = %lu", (unsigned long)idx);
    
    
    if (idx == NSNotFound)
    {
        KRNPeripheralWithAttr* temp = [KRNPeripheralWithAttr new];
        
        temp.peripheral = [peripheral copy]; // копируем peripheral
        
        
        [temp addAssociatedRSSI:RSSI andAdvertisemendData:advertisementData]; // добавляем данные
        
        
        [_findedPeripherals addObject:temp];
        
        [_coreDataController addKRNPeripheral:temp];
        
        
        
        
   
    }
        else
        {
            
            
            [_findedPeripherals[idx] addAssociatedRSSI:RSSI andAdvertisemendData:advertisementData]; // меняем данные по найденному индексу
            

            
            //NSLog(@"%@", RSSI.stringValue);
        }
    
    dispatch_async(dispatch_get_main_queue(), ^{ // перегружаем tableVIew в главном потоке
         [self.tableView reloadData];
    });
    
}

- (IBAction)scanButtonAction:(id)sender
{
    
    
    if (currentScanButtonState == NO)
    {
        if (_bluetoothManager.state == CBCentralManagerStatePoweredOn)
        {
           
                  [_bluetoothManager scanForPeripheralsWithServices:nil options:nil]; // запускаем сканирование
          
          
            [_scanButton setTitle:@"Stop" forState:UIControlStateNormal];
            _scanActivityIndicator.hidden = NO;
            currentScanButtonState = YES;
        }
    }
    else
        {
            [_bluetoothManager stopScan];
            [_scanButton setTitle:@"Start" forState:UIControlStateNormal];
            _scanActivityIndicator.hidden = YES;
            currentScanButtonState = NO;
        }
}





// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"toExtendedTVC"])
    {
    KRNExtendedTVC *destinationTVC = segue.destinationViewController;
    
    // передаем необходимые данные
 destinationTVC.concretePeripheral = _findedPeripherals[selectedRow];
    }
    
}




@end
