//
//  KRNCoreData.h
//  TableInTable
//
//  Created by Drapaylo Yulian on 01.11.15.
//  Copyright © 2015 Administrator. All rights reserved.
//

#import <Foundation/Foundation.h>
@import CoreData;


@interface KRNCoreData : NSObject


@property (strong, nonatomic) NSManagedObjectContext* managedObjectContext;
@property (strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (strong, nonatomic) NSManagedObjectModel* managedObjectModel;

-(void)saveContext; // сохранить контекст\


+(KRNCoreData*) defaultCoreData; // defaultCoreData - singleton method

@end
