//
//  KRNExtendedTVC.h
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 29.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KRNPeripheralAccessoryData.h"
#import "KRNPeripheralCell.h"
@import CoreBluetooth;

#import <Foundation/Foundation.h>

#import "KRNPeripheralWithAttr.h"

@interface NSData (NSData_Conversion)

#pragma mark - String Conversion
- (NSString *)hexadecimalString;

@end

@protocol KRNExtendedTVCProtocol;



@interface KRNExtendedTVC : UITableViewController

//@property (weak) id<KRNExtendedTVCProtocol> concretePeripheral; // периферийное устройство, о котором будем получать информацию

@property (weak) id<KRNExtendedTVCProtocol> concretePeripheral; // периферийное устройство, о котором будем получать информацию

@end


