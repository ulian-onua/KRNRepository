//
//  KRNPeripheralCDController.h
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 10.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KRNCoreData.h"
#import "KRNPeripheralWithAttr.h"
@import CoreBluetooth;

#import "PeripheralDevice.h"
#import "AdvertisementData.h"



@protocol KRNPeripheralCDControllerProtocol;

@interface KRNPeripheralCDController : NSObject



@property NSMutableArray<PeripheralDevice*> *fetchedPeripherals;


-(id) initWithCDContext:(NSManagedObjectContext*) context AndDelegate:(id<KRNPeripheralCDControllerProtocol>) delegate;

-(BOOL) addKRNPeripheral:(KRNPeripheralWithAttr*)peripheral;

-(NSArray<PeripheralDevice*> *) fetchAllPeripheralDevicesFromCD;
-(BOOL)deleteAllKRNPeripheralsFromCD;
-(BOOL) deleteKRNPeripheralAtRow:(NSUInteger)tableViewRow;


@property id<KRNPeripheralCDControllerProtocol> delegate;

@end


@protocol KRNPeripheralCDControllerProtocol  <NSObject>
@optional

-(void) findedNoPeripheralsinCD:(KRNPeripheralCDController*) controller; // ни одного периферийного устройства не найдено

-(void) peripheralsinCDFound:(KRNPeripheralCDController*) controller; // найден один или более периферийных устройств в CD


@end


@interface CBUUID (NSCoding)

- (instancetype)initWithCoder:(NSCoder *)decoder;
- (void)encodeWithCoder:(NSCoder *)encoder;



@end