//
//  KRNPeripheralWithAttr.m
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 02.12.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "KRNPeripheralWithAttr.h"

@implementation KRNPeripheralWithAttr



-(void) addAssociatedRSSI:(NSNumber *) RSSI andAdvertisemendData: (NSDictionary<NSString *, id> *) data
{
    
    _associatedRSSI = RSSI;
    _associatedDate = [NSDate date];
    _advertisementData = [NSDictionary dictionaryWithDictionary:data];

}


@end
