//
//  KRNPeripheralCell.m
//  testBluetoothIos
//
//  Created by Drapaylo Yulian on 28.11.15.
//  Copyright © 2015 Drapaylo Yulian. All rights reserved.
//

#import "KRNPeripheralCell.h"

@implementation KRNPeripheralCell

- (void)awakeFromNib {
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void) addNeededName:(NSString*)name ID:(NSString*) identifier RSSI: (NSString*) rssi andDate:(NSDate*) date
{
    _peripheralDeviceName.text = [NSString stringWithString:name];
    _peripheralDeviceID.text = [NSString stringWithFormat:@"ID: %@", identifier];
    _peripheralDeviceRSSI.text = [NSString stringWithFormat:@"RSSI: %@", rssi];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss.SSS"];
    
    _timeOfDiscover.text = [NSString stringWithFormat:@"%@", [dateFormatter stringFromDate: date]];

}





@end
